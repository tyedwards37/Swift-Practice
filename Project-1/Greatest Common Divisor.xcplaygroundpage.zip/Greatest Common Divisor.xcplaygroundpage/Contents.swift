//: [Previous - Prime Number](@previous)
//: # Greatest Common Divisor
/*: * Selected a basic function, that returned an integer since we are returning the greatest common divisor, which is a value.
 * Parameters: 
    * n - Int - one of the numbers
    * check - Int - other number */
/*: *Psuedo Code*\
see if check is 0 -> return n\
if not recursively call the function with the check and n % check\ */

import Foundation

func gcd(_ n: Int, _ check: Int) -> Int {
    if(check == 0) {
        return n
    } else {
        return gcd(check, n % check)
    }
}

gcd(3, 9)
gcd(60, 48)

//: [Next - Waiting Time](@next)
