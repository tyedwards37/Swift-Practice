//: [Previous - Introduction](@previous)
//: # Prime Number
/*: * Selected a basic function, that returned a boolean since we are answering a true or false question: Is the number prime?
 * Parameter: number - Int - number you are checking
 * Constant: check - Int - calculate the half of the original number since after that number times two, there's no other possible divisors */
/*: *Psuedo Code*\
check if number is smaller than 3 -> return true\
find value of number / 2\
loop for i to half {\
 | check if number is divisible using % (mod) -> return false \
 }\
if it hasn't already returned false return true */

import Foundation

func isPrime(_ number: Int) -> Bool {
    if (number <= 3) {
        return true
    }
        
    let check = Int(Double(number) / 2)
    
    for i in 2...check {
        if (number % i == 0) {
            return false
        }
    }
    
    return true
}

isPrime(3) // true
isPrime(83) // true
isPrime(84) // false

//: [Next - Greatest Common Divisor](@next)
