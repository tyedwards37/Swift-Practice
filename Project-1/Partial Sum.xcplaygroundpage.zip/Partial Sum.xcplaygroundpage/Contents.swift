//: [Previous - Correct Parenthesis](@previous)
//: # Partial Sum
/*: * Selected a basic function, that returns an array of strings, since there can be multiple integer answers.
 * Parameters:
    * nums - Array: Int - array of numbers we will be using to calculate the partial sums
    * pairs - Array: [Int, Int] - array of tuples that will specify the indexes to use in the partial sums
 * Constant:
    * (a, b) - Tuple of Ints - used to store the pair for the current sum
 * Variables:
    * sums - Array: Int - stores the final sums that will be outputted
    * currentSum - Int - the sum of the current pair */
/*: *Psuedo Code*\
intialize the sums array to 0\
loop for pair in pairs {\
 | create a constant to represent the pair and set it equal to pair \
 | create variable that is the current sum and set it equal to the array at index a + at index b \
 | append the current sum to the sums array \
 }\
return sums */

import Foundation

func partialSum(_ nums: [Int], _ pairs: [(Int, Int)]) -> [Int] {
    var sums: [Int] = []
    
    for pair in pairs {
        let (a, b) = pair
        var currentSum = nums[a] + nums[b]
        sums.append(currentSum)
    }
    
    return sums
}

let numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
let pairs = [(1, 3), (4, 7), (2, 5)]
let result = partialSum(numbers, pairs)

//: [Next - Sum of Powers](@next)
