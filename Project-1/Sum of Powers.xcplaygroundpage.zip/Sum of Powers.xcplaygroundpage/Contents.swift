//: [Previous - Partial Sum](@previous)
//: # Sum of Powers
/*: * Selected a closure function, that set a variable to the value of the the sum of powers.
 * Parameters:
    * power - Int - the exponent value that you raise 1 to base to
    * base - Int - the end value of the bases that are raisde to the power of the power var
 * Variables:
    * sum - Int - stores the total sum of all of the powers */
/*: *Psuedo Code*\
intialize sum to 0\
loop for values 1 to base with i {\
 | increment sum by i to the power of the power parameter \
 }\
return sum */

import Foundation

let sumOfPowers = {(_ power: Int, _ base: Int) -> Int in
    var sum = 0
    for i in 1...base {
        sum += Int(pow(Double(i), Double(power)))
    }
    
    return sum
}

let answer = sumOfPowers(2, 5)

