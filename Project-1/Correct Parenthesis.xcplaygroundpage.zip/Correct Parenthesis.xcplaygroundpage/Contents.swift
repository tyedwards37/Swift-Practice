//: [Previous - Waiting Time](@previous)
//: # Correct Parenthesis
/*: * Selected a basic function, that returned a boolean since we are answering a true or false question: Are the parenthesis correct?
 * Parameter: check - String - string of parenthesis we are checking
 * Variables:
    * left - Int - counts how many left parenthesis there are
    * right - Int - count how many right parenthesis there are */
/*: *Psuedo Code*\
intialize left and right variables to 0\
loop for every character in the string {\
 | check if the charcter is "(" -> increment left by 1 \
 | check if the character is ")" -> increment right by 1 \
 }\
 check if left is equal to right -> return true\
if it hasn't already returned true return false (default) */

import Foundation

func verifyParenthesis(_ check: String) -> Bool {
    var left = 0, right = 0
    
    for c in check {
        if (c == "(") {
            left += 1
        } else if (c == ")") {
            right += 1
        }
    }
    
    if (left == right) {
        return true
    }
    
    return false
}

verifyParenthesis("(())")
verifyParenthesis("()")
verifyParenthesis("))")

//: [Next - Check Email](@next)
