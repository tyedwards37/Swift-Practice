import UIKit

//: # Introduction
//: **CPSC357 - Project 1** | *By Tyler Edwards*
/*: * Prime Number
* Greatest Common Divisor
* Waiting Time
* Correct Parenthesis
* Partial Sum
* Sum of Powers
 */
//: [Next - Prime Number](@next)
