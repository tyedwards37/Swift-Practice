//: [Previous - Greatest Common Divisor](@previous)
//: # Waiting Time
/*: * Selected a basic function with no return since the function is just meant to print a statement based on the given values
 * Parameters:
    * firstHour - Int - first hour value
    * firstMinute - Int - first minute value
    * secondHour - Int - second hour value
    * secondMinute - Int - second minute value
 * Varaiables:
    * totalHours - Int - value that stores how many hours are between the two times
    * totalMinutes - Int - value that stores how many minutes are between the two times
    * hourTemp - Int - used in the calculation to increment until it reaches the second Hour amount
    * minuteTemp - Int - used in the calculation to increment until it reaches the second Minute amount  */
/*: *Psuedo Code*\
intialize total values = 0\
set temp varaibles equal to the first hour and minute values\
loop while the temp minute value isn't equal to the second minute value {\
 | check if the temp value has hit 60 {\
 | | set temp value back to 0 so it will be incremented to 1 next time\
 | | increment hour temp value by one to account for 60 minutes \
 | }\
 | increment minuite temp value and total minutes by 1\
 }\
 loop while the temp hour value isn't equal to the second hour value {\
  | check if the temp value has hit 24 {\
  | | set temp value back to 0 so it will be incremented to 1 next time\
  | }\
  | increment hour temp value and total hours by 1\
  }\
print with the values */

import Foundation

func waitingTime(_ firstHour: Int, _ firstMinute: Int, _ secondHour: Int, _ secondMinute: Int) {
    var totalHours = 0, totalMinutes = 0
    
    var hourTemp = firstHour
    var minuteTemp = firstMinute
    while (minuteTemp != secondMinute) {
        if (minuteTemp == 60) {
            minuteTemp = 0
            hourTemp += 1
        }
        
        minuteTemp += 1
        totalMinutes += 1
    }
    
    while (hourTemp != secondHour) {
        if (hourTemp == 24) {
            hourTemp = 0
        }
        
        hourTemp += 1
        totalHours += 1
    }
    
    print("You should wait \(totalHours) hours and \(totalMinutes) minutes.")
}

waitingTime(11, 30, 13, 15)

//: [Next - Correct Parenthesis](@next)
