//
//  ObservableApp.swift
//  Observable
//
//  Created by student on 3/14/24.
//

import SwiftUI

@main
struct ObservableApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
