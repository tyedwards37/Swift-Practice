//
//  ContentView.swift
//  CardPresentation
//
//  Created by student on 3/5/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Image("logo")
            .resizable()
            .scaledToFit()
            .frame(width: 100, height: 100)
        Text("Tyler Edwards")
            .font(.custom("Bodoni 72", size: 50))
            .fontWeight(.bold)
            .foregroundColor(Color(red: 0.5882, green: 0.0392, blue: 0.1725, opacity: 1.0))
        Text("tyedwards@chapman.edu")
            .font(.custom("Avenir Next", size: 15))
            .padding(.bottom)
        Text("Computer Science • Creative Writing")
            .font(.custom("Palatino", size: 20))
        Text("Chapman University Class of 2025")
            .font(.custom("Palatino", size: 20))
        Text("Insta - @tyler.kiyoshi")
            .font(.custom("Palatino", size: 20))
    }
}

#Preview {
    ContentView()
}
