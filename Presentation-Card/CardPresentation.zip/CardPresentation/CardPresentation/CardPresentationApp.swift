//
//  CardPresentationApp.swift
//  CardPresentation
//
//  Created by student on 3/5/24.
//

import SwiftUI

@main
struct CardPresentationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
