//
//  pokemonStateApp.swift
//  pokemonState
//
//  Created by student on 3/12/24.
//

import SwiftUI

@main
struct pokemonStateApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
