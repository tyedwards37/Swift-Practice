//
//  DataflowApp.swift
//  Dataflow
//
//  Created by student on 3/25/24.
//

import SwiftUI

@main
struct DataflowApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
